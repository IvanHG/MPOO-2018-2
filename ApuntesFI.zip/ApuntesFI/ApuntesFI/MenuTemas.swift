//
//  MenuTemas.swift
//  ApuntesFI
//
//  Created by macbook on 01/06/18.
//  Copyright © 2018 Macbook. All rights reserved.
//

import UIKit

class MenuTemas: UIViewController, UITableViewDelegate, UITableViewDataSource{
    
    @IBOutlet weak var MenuTemasViewController: UITableView!
    
   // let secciones = materias[indexP].temas
    var indexP: Int = 0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.MenuTemasViewController.delegate = self
        self.MenuTemasViewController.dataSource = self
        
        self.title = materias[indexP].nombre
        
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return /*secciones.count*/ materias[indexP].temas.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return /*secciones[section].subtemas.count*/ materias[indexP].temas[section].subtemas.count
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return /*secciones[section].nombre*/ materias[indexP].temas[section].nombre
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell_Tema", for: indexPath) as! CeldaTema
        cell.textLabel?.text = /*secciones[indexPath.section].subtemas[indexPath.row]*/ materias[indexP].temas[indexPath.section].subtemas[indexPath.row]
        return cell
    }
    
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
