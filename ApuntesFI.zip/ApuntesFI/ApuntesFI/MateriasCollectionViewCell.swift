//
//  MateriasCollectionViewCell.swift
//  ApuntesFI
//
//  Created by macbook on 31/05/18.
//  Copyright © 2018 Macbook. All rights reserved.
//

import UIKit

class MateriasCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var imgMateria: UIImageView!
    
    @IBOutlet weak var nomMateria: UILabel!
}
