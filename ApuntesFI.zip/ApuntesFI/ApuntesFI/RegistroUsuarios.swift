//
//  RegistroUsuarios.swift
//  ApuntesFI
//
//  Created by macbook on 03/04/18.
//  Copyright © 2018 Macbook. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth
import FirebaseStorage
import FirebaseDatabase

class RegistroUsuarios: UIViewController, UINavigationControllerDelegate, UIImagePickerControllerDelegate{
    
    var databRef: DatabaseReference!
    var StorageRef: StorageReference!
    
// variables pàra el diseño dela vista
    @IBOutlet weak var registrarse: UIButton!
    @IBOutlet weak var alerta: UILabel!
    
// Datos del usuario
    @IBOutlet weak var fotoPerfil: UIImageView!
    @IBOutlet weak var nombreUsuario: UITextField!
    @IBOutlet weak var correo: UITextField!
    @IBOutlet weak var cfirmCorreo: UITextField!
    @IBOutlet weak var contraseña: UITextField!
    @IBOutlet weak var cfirmContraseña: UITextField!
    

    
// variable para manejar la camara y la libreria de fotos
    let imagePicker: UIImagePickerController = UIImagePickerController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 200/255, green: 90/255, blue: 60/255, alpha: 1.0)
        
        databRef = Database().reference()
       // StorageRef = Storage.storage().reference()
        
        
        imagePicker.delegate = self
        
        fotoPerfil.isUserInteractionEnabled = true
        fotoPerfil.backgroundColor = .gray
        fotoPerfil.layer.cornerRadius = fotoPerfil.bounds.width / 2.0
        fotoPerfil.layer.masksToBounds = true
        
        registrarse.isEnabled = false
        registrarse.layer.cornerRadius = 15
        
        let gesto = UITapGestureRecognizer(target: self, action: #selector(self.SelectFoto))
        gesto.numberOfTapsRequired = 2
        self.fotoPerfil.addGestureRecognizer(gesto)
    }
    
//  Verificacion de los Datos Solicitados
    @IBAction func ValUsuario(_ sender: Any) {
        if nombreUsuario.text!.count != 0 && correo.text!.count != 0 && cfirmCorreo.text!.count != 0 && contraseña.text!.count != 0 && cfirmContraseña.text!.count != 0{
            registrarse.isEnabled = true
        }else{
            registrarse.isEnabled = false
        }
    }
    
    @IBAction func ValCorreo(_ sender: Any) {
        if nombreUsuario.text!.count != 0 && correo.text!.count != 0 && cfirmCorreo.text!.count != 0 && contraseña.text!.count != 0 && cfirmContraseña.text!.count != 0{
            registrarse.isEnabled = true
        }else{
            registrarse.isEnabled = false
        }
    }
    
    @IBAction func ValCCorreo(_ sender: Any) {
        if nombreUsuario.text!.count != 0 && correo.text!.count != 0 && cfirmCorreo.text!.count != 0 && contraseña.text!.count != 0 && cfirmContraseña.text!.count != 0{
            registrarse.isEnabled = true
        }else{
            registrarse.isEnabled = false
        }
    }
    
    @IBAction func ValContraseña(_ sender: Any) {
        if nombreUsuario.text!.count != 0 && correo.text!.count != 0 && cfirmCorreo.text!.count != 0 && contraseña.text!.count != 0 && cfirmContraseña.text!.count != 0{
            registrarse.isEnabled = true
        }else{
            registrarse.isEnabled = false
        }
    }
    
    @IBAction func ValCContra(_ sender: Any) {
        if nombreUsuario.text!.count != 0 && correo.text!.count != 0 && cfirmCorreo.text!.count != 0 && contraseña.text!.count != 0 && cfirmContraseña.text!.count != 0{
            registrarse.isEnabled = true
        }else{
            registrarse.isEnabled = false
        }
    }

//Registro de usuarios en la base de datos
    @IBAction func registrarUsuario(_ sender: UIButton) {
//        let email = correo.text!
//        let pasword = contraseña.text!
        let data = UIImageJPEGRepresentation(self.fotoPerfil.image!, 0.8)
        
        print("Data es:\(data!)")
        
        if contraseña.text!.count < 6{
            alerta.text = "La contraseña debe tener almenos 6 caracteres"
            alerta.textColor = UIColor.red
        }else{
            //registro de usuarios
            print("todo parece bien")
            
            self.signUp(userName: nombreUsuario.text!, correo: correo.text!, password: contraseña.text!, data: data! as NSData)
        }
    }


// Metodos paa el manejo de la camara y la libreria de fotos
    @objc func SelectFoto(){
        if UIImagePickerController.isSourceTypeAvailable(.photoLibrary){
            
            imagePicker.allowsEditing = false
            imagePicker.sourceType = .photoLibrary
            
            present(imagePicker,animated: true,completion: nil)
        }
    }

    @IBAction func Fotografia(_ sender: UIButton) {
        
        if UIImagePickerController.isSourceTypeAvailable(.camera){
            if UIImagePickerController.availableCaptureModes(for: .rear) != nil {
                imagePicker.allowsEditing = false
                imagePicker.sourceType = .camera
                imagePicker.cameraCaptureMode = .photo
                
                present(imagePicker,animated: true,completion: nil)
            }
        }
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        if let imgSelected: UIImage = info["UIImagePickerControllerOriginalImage"] as? UIImage {
            
//            print("_______________________________")
//            dump(info)
//            print("_______________________________")
            fotoPerfil.image = imgSelected
//            print(imgSelected.imageAsset)
//            print("________________________________________________________")
//            print(imgSelected.)
            
            if imagePicker.sourceType == .camera {
                UIImageWriteToSavedPhotosAlbum(imgSelected, nil, nil, nil)
            }
        }
        
        imagePicker.dismiss(animated: true, completion: nil)
    }
    
//   Funcion de Alerta en Pantalla
    
    func mostrarMensageAlerta(_ mensageUsuario:String){
        let alerta = UIAlertController(title:"Atencion!!", message: mensageUsuario, preferredStyle: UIAlertControllerStyle.alert)

        let okAction = UIAlertAction(title:"OK", style: UIAlertActionStyle.default, handler: nil)

        alerta.addAction(okAction)
        present(alerta, animated:true, completion:nil)
    }
    
//Funcion para crear usuarios
    
    func signUp(userName: String, correo: String ,password: String, data: NSData!){
        
        Auth.auth().createUser(withEmail: correo, password: password, completion: {(user, error) in
            
            if user != nil{
                print("usuario creado")
                
                let infoUser = ["nombre": userName, "correo": correo, "contraseña": password, "Foto de Perfil": "hola" ]

                guard let uid = user?.uid else{return}
                
                let userReference = self.databRef.child("Usuarios").child(uid)
                
                userReference.updateChildValues(infoUser, withCompletionBlock: { (error, databaseRef) in
                    if error != nil {
                        print("No se agregaron los datos")
                        return
                    }else{
                        print("se guardo la informacion")
                    }
                })
                self.performSegue(withIdentifier: "Segue_Inicio", sender: self)
            }else{
                
                if let miError = error?.localizedDescription{
                    print(miError)
                    self.mostrarMensageAlerta("Revisa tus datos proporcionados")
                    
                }else{
                    print("ERROR FATAL")
                    self.mostrarMensageAlerta("Revisa tus datos proporcionados")
                }
            }
        })
    }

    
//guardar datos del usuario en base de datos
    
//    func registrarDatos(user: User!, userName: String, password: String, data: NSData!){
//        let rutaImagen = "fotoPerfil\(user.uid)/UsuarioFoto.jpg"
//        
//        let ImagRef = StorageRef.child(rutaImagen)
//        
//        let metaDato = StorageMetadata()
//        metaDato.contentType = "imagen/jpg"
//        
//        ImagRef.putData(data as Data, metadata: metaDato) { (metaDato, error) in
//            if error == nil{
//                
//                let cambio = user.createProfileChangeRequest()
//                cambio.displayName = userName
//                cambio.photoURL = metaDato!.downloadURL()
//                cambio.commitChanges(completion: { (error) in
//                    if error == nil{
//                        
//                        //guardamos datos del usuario
//                        print("guardando datos compa")
//                        self.infoUserSave(usuario: user, nombreUsuario: userName, contraseña: password)
//                        
//                        }else{
//                            print(error?.localizedDescription)
//                        }
//                })
//                
//            }else{
//                print(error?.localizedDescription)
//            }
//        }
//    }
//
//
//    func infoUserSave(usuario: User!, nombreUsuario: String, contraseña: String){
//        
//        let infoUser = ["uid": usuario.uid,"nombre": nombreUsuario, "correo": usuario.email!, "fotoPerfil": usuario.displayName! ]
//        guard let uid = usuario?.uid else{return}
//        
//        let userRef = databRef.child("Usuarios").child(usuario.uid).child(uid)
//        userRef.updateChildValues(infoUser, withCompletionBlock: { (error,DatabaseRef) in
//            if error != nil{
//                print("error no valores")
//                return
//            }else{
//                print("todo bien otra vez")
//            }
//        })
//    }
    

}
