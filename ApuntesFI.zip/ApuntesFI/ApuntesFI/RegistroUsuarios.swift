//
//  RegistroUsuarios.swift
//  ApuntesFI
//
//  Created by macbook on 03/04/18.
//  Copyright © 2018 Macbook. All rights reserved.
//

import UIKit
import Firebase

class RegistroUsuarios: UIViewController, UINavigationControllerDelegate, UIImagePickerControllerDelegate{
    
    
    @IBOutlet weak var fotoPerfil: UIImageView!
    @IBOutlet weak var nombreUsuario: UITextField!
    @IBOutlet weak var correo: UITextField!
    @IBOutlet weak var cfirmCorreo: UITextField!
    @IBOutlet weak var contraseña: UITextField!
    @IBOutlet weak var cfirmContraseña: UITextField!
    
    @IBOutlet weak var alerta: UILabel!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = UIColor(red: 200/255, green: 90/255, blue: 60/255, alpha: 1.0)
        fotoPerfil.layer.masksToBounds = false
        fotoPerfil.layer.cornerRadius = fotoPerfil.bounds.size.width / 2.0
    }
    
    
    @IBAction func registrarUsuario(_ sender: UIButton) {
        
        if correo.text! != cfirmCorreo.text! {
            
            alerta.textColor = UIColor.red
            alerta.text = "Ups!! Los correos no coinsiden"
            
//            mostrarMensageAlerta("Los correos no coinsiden")
        }
        else if contraseña.text! != cfirmContraseña.text!{
            
            alerta.textColor = UIColor.red
            alerta.text = "Ups!! Las contraseñas no coinsiden"
            
//            mostrarMensageAlerta("Las contraseñas no coinsiden")
        }
        else if (correo.text == "" || cfirmCorreo.text == "" || contraseña.text == "" || cfirmContraseña.text == "" || nombreUsuario.text == ""){
            
            alerta.textColor = UIColor.red
            alerta.text = "Upss!! Te falto ingresar algun dato"
            
            //            mostrarMensageAlerta("Por favor introduce todos los datos solicitados")
        }
            
        else{
            alerta.textColor = UIColor.black
            alerta.text = "Todo parece en orden para continuar"
            
//            mostrarMensageAlerta("Turegistro ha sido completado exitosamente")
            //registrar usuario en la base de datos
        }
        
        
    }
    
    @IBAction func Fotografia(_ sender: UIButton) {
        
        
        
    }
    
    
    
    
//    func mostrarMensageAlerta(_ mensageUsuario:String){
//        let alerta = UIAlertController(title:"Atencion!!", message: mensageUsuario, preferredStyle: UIAlertControllerStyle.alert)
//
//        let okAction = UIAlertAction(title:"OK", style: UIAlertActionStyle.default, handler: nil)
//
//        alerta.addAction(okAction)
//        present(alerta, animated:true, completion:nil)
//    }
    

    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
