//
//  RegistroUsuarios.swift
//  ApuntesFI
//
//  Created by macbook on 03/04/18.
//  Copyright © 2018 Macbook. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth

class RegistroUsuarios: UIViewController, UINavigationControllerDelegate, UIImagePickerControllerDelegate{
    
    var ref: DatabaseReference!
    
// variables pàra el diseño dela vista
    @IBOutlet weak var registrarse: UIButton!
    @IBOutlet weak var alerta: UILabel!
    
// Datos del usuario
    @IBOutlet weak var fotoPerfil: UIImageView!
    @IBOutlet weak var nombreUsuario: UITextField!
    @IBOutlet weak var correo: UITextField!
    @IBOutlet weak var cfirmCorreo: UITextField!
    @IBOutlet weak var contraseña: UITextField!
    @IBOutlet weak var cfirmContraseña: UITextField!
    
// variable para manejar la camara y la libreria de fotos
    let imagePicker: UIImagePickerController = UIImagePickerController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 200/255, green: 90/255, blue: 60/255, alpha: 1.0)
        
        imagePicker.delegate = self
        
        fotoPerfil.isUserInteractionEnabled = true
        fotoPerfil.backgroundColor = .gray
        fotoPerfil.layer.cornerRadius = 50
        
        registrarse.isEnabled = false
        registrarse.layer.cornerRadius = 15
        
        let gesto = UITapGestureRecognizer(target: self, action: #selector(self.SelectFoto))
        gesto.numberOfTapsRequired = 2
        self.fotoPerfil.addGestureRecognizer(gesto)
    }
    
//  Verificacion de los Datos Solicitados
    @IBAction func registrarUsuario(_ sender: UIButton) {
        
        let i = validacionDatos()
        
        if i == true{
            let email = correo.text!
            let pasword = contraseña.text!
            
            Auth.auth().createUser(withEmail: email, password: pasword, completion: {(user, error) in
                
                if error != nil{
                    print("usuafrio creado")
                }else{
                    print("error")
                }
            })
        }
    }
    
    func validacionDatos() -> Bool{
        var validacion: Bool = false
        
        if (correo.text != "" || cfirmCorreo.text != "" || contraseña.text != "" || cfirmContraseña.text != "" || nombreUsuario.text != ""){
            
            alerta.text = "todo parece bien para continuar"
            registrarse.isEnabled = true
            
        }
        
        
        
        
        
        
        
        
        
        
        

        if correo.text! != cfirmCorreo.text! {

            alerta.textColor = UIColor.red
            alerta.text = "Ups!! Los correos no coinsiden"

            //            mostrarMensageAlerta("Los correos no coinsiden")
        }
        else if contraseña.text! != cfirmContraseña.text!{

            alerta.textColor = UIColor.red
            alerta.text = "Ups!! Las contraseñas no coinsiden"

            //            mostrarMensageAlerta("Las contraseñas no coinsiden")
        }
        else if (correo.text == "" || cfirmCorreo.text == "" || contraseña.text == "" || cfirmContraseña.text == "" || nombreUsuario.text == ""){

            alerta.textColor = UIColor.red
            alerta.text = "Upss!! Te falto ingresar algun dato"

            //            mostrarMensageAlerta("Por favor introduce todos los datos solicitados")
        }

        else{
            alerta.textColor = UIColor.black
            alerta.text = "Todo parece en orden para continuar"
            registrarse.isEnabled = true
            
            validacion = true
        }
        
        return validacion
    }
    
    
    
    
//            mostrarMensageAlerta("Turegistro ha sido completado exitosamente")
            
//       *****     registrar usuario en la base de datos   ******
//            let email = correo.text!
//            let pasword = contraseña.text!
            
//            Auth.auth().createUser(withEmail: correo.text!, password: contraseña.text!){(user, error) in
////                
//////                    let datos = ["email": email]
//////                    let uid = user?.uid
//////                    let referencia = self.ref.child("users").child(uid!)
//////                    referencia.ref.updateChildValues(datos, withCompletionBlock: {(error, databaseRef) in
//                
//                        if error != nil {
//                            print("todo bien")
//                            return
//                        }else{
//                        print("error")
//                        }
//                    }
            
                //}
            //}
     
    
// Metodos paa el manejo de la camara y la libreria de fotos
    @objc func SelectFoto(){
        if UIImagePickerController.isSourceTypeAvailable(.photoLibrary){
            
            imagePicker.allowsEditing = false
            imagePicker.sourceType = .photoLibrary
            
            present(imagePicker,animated: true,completion: nil)
        }
    }

    @IBAction func Fotografia(_ sender: UIButton) {
        
        if UIImagePickerController.isSourceTypeAvailable(.camera){
            if UIImagePickerController.availableCaptureModes(for: .rear) != nil {
                imagePicker.allowsEditing = false
                imagePicker.sourceType = .camera
                imagePicker.cameraCaptureMode = .photo
                
                present(imagePicker,animated: true,completion: nil)
            }
        }
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        if let imgSelected: UIImage = info[UIImagePickerControllerOriginalImage] as? UIImage {
            
            fotoPerfil.image = imgSelected
            
            if imagePicker.sourceType == .camera {
                UIImageWriteToSavedPhotosAlbum(imgSelected, nil, nil, nil)
            }
        }
        
        imagePicker.dismiss(animated: true, completion: nil)
    }
    
    
//   Funcion de Alerta en Pantalla
    
//    func mostrarMensageAlerta(_ mensageUsuario:String){
//        let alerta = UIAlertController(title:"Atencion!!", message: mensageUsuario, preferredStyle: UIAlertControllerStyle.alert)
//
//        let okAction = UIAlertAction(title:"OK", style: UIAlertActionStyle.default, handler: nil)
//
//        alerta.addAction(okAction)
//        present(alerta, animated:true, completion:nil)
//    }
    
}
