//
//  RegistroUsuarios.swift
//  ApuntesFI
//
//  Created by macbook on 03/04/18.
//  Copyright © 2018 Macbook. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth

class RegistroUsuarios: UIViewController, UINavigationControllerDelegate, UIImagePickerControllerDelegate{
    
    var ref: DatabaseReference!
    
// variables pàra el diseño dela vista
    @IBOutlet weak var registrarse: UIButton!
    @IBOutlet weak var alerta: UILabel!
    
// Datos del usuario
    @IBOutlet weak var fotoPerfil: UIImageView!
    @IBOutlet weak var nombreUsuario: UITextField!
    @IBOutlet weak var correo: UITextField!
    @IBOutlet weak var cfirmCorreo: UITextField!
    @IBOutlet weak var contraseña: UITextField!
    @IBOutlet weak var cfirmContraseña: UITextField!
    
// variable para manejar la camara y la libreria de fotos
    let imagePicker: UIImagePickerController = UIImagePickerController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 200/255, green: 90/255, blue: 60/255, alpha: 1.0)
        
        imagePicker.delegate = self
        
        fotoPerfil.isUserInteractionEnabled = true
        fotoPerfil.backgroundColor = .gray
        fotoPerfil.layer.cornerRadius = 50
        
        registrarse.isEnabled = false
        registrarse.layer.cornerRadius = 15
        
        let gesto = UITapGestureRecognizer(target: self, action: #selector(self.SelectFoto))
        gesto.numberOfTapsRequired = 2
        self.fotoPerfil.addGestureRecognizer(gesto)
    }
    
//  Verificacion de los Datos Solicitados
    @IBAction func ValUsuario(_ sender: Any) {
        if nombreUsuario.text!.count != 0 && correo.text!.count != 0 && cfirmCorreo.text!.count != 0 && contraseña.text!.count != 0 && cfirmContraseña.text!.count != 0{
            registrarse.isEnabled = true
        }else{
            registrarse.isEnabled = false
        }
    }
    
    @IBAction func ValCorreo(_ sender: Any) {
        if nombreUsuario.text!.count != 0 && correo.text!.count != 0 && cfirmCorreo.text!.count != 0 && contraseña.text!.count != 0 && cfirmContraseña.text!.count != 0{
            registrarse.isEnabled = true
        }else{
            registrarse.isEnabled = false
        }
    }
    
    @IBAction func ValCCorreo(_ sender: Any) {
        if nombreUsuario.text!.count != 0 && correo.text!.count != 0 && cfirmCorreo.text!.count != 0 && contraseña.text!.count != 0 && cfirmContraseña.text!.count != 0{
            registrarse.isEnabled = true
        }else{
            registrarse.isEnabled = false
        }
    }
    
    @IBAction func ValContraseña(_ sender: Any) {
        if nombreUsuario.text!.count != 0 && correo.text!.count != 0 && cfirmCorreo.text!.count != 0 && contraseña.text!.count != 0 && cfirmContraseña.text!.count != 0{
            registrarse.isEnabled = true
        }else{
            registrarse.isEnabled = false
        }
    }
    
    @IBAction func ValCContra(_ sender: Any) {
        if nombreUsuario.text!.count != 0 && correo.text!.count != 0 && cfirmCorreo.text!.count != 0 && contraseña.text!.count != 0 && cfirmContraseña.text!.count != 0{
            registrarse.isEnabled = true
        }else{
            registrarse.isEnabled = false
        }
    }

//Registro de usuarios en la base de datos
    @IBAction func registrarUsuario(_ sender: UIButton) {
        let email = correo.text!
        let pasword = contraseña.text!
        
        if pasword.count < 6{
            alerta.text = "La contraseña debe tener almenos 6 caracteres"
            alerta.textColor = UIColor.red
        }else{
            
            Auth.auth().createUser(withEmail: email, password: pasword, completion: {(user, error) in
                
                if user != nil{
                    print("usuario creado")
                    self.performSegue(withIdentifier: "Segue_Inicio", sender: self)
                }else{
        
                    if let miError = error?.localizedDescription{
                        print(miError)
                        self.mostrarMensageAlerta("Revisa tus datos proporcionados")
                        
                    }else{
                        print("ERROR FATAL")
                        self.mostrarMensageAlerta("Revisa tus datos proporcionados")
                    }
                }
            })
        }
    }


// Metodos paa el manejo de la camara y la libreria de fotos
    @objc func SelectFoto(){
        if UIImagePickerController.isSourceTypeAvailable(.photoLibrary){
            
            imagePicker.allowsEditing = false
            imagePicker.sourceType = .photoLibrary
            
            present(imagePicker,animated: true,completion: nil)
        }
    }

    @IBAction func Fotografia(_ sender: UIButton) {
        
        if UIImagePickerController.isSourceTypeAvailable(.camera){
            if UIImagePickerController.availableCaptureModes(for: .rear) != nil {
                imagePicker.allowsEditing = false
                imagePicker.sourceType = .camera
                imagePicker.cameraCaptureMode = .photo
                
                present(imagePicker,animated: true,completion: nil)
            }
        }
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        if let imgSelected: UIImage = info[UIImagePickerControllerOriginalImage] as? UIImage {
            
            fotoPerfil.image = imgSelected
            
            if imagePicker.sourceType == .camera {
                UIImageWriteToSavedPhotosAlbum(imgSelected, nil, nil, nil)
            }
        }
        
        imagePicker.dismiss(animated: true, completion: nil)
    }
    
//   Funcion de Alerta en Pantalla
    
    func mostrarMensageAlerta(_ mensageUsuario:String){
        let alerta = UIAlertController(title:"Atencion!!", message: mensageUsuario, preferredStyle: UIAlertControllerStyle.alert)

        let okAction = UIAlertAction(title:"OK", style: UIAlertActionStyle.default, handler: nil)

        alerta.addAction(okAction)
        present(alerta, animated:true, completion:nil)
    }
    
}
