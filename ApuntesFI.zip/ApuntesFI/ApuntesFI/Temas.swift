//
//  Temas.swift
//  ApuntesFI
//
//  Created by macbook on 01/06/18.
//  Copyright © 2018 Macbook. All rights reserved.
//

import Foundation

struct Temas{
    let nombre: String
    let subtemas: [String]
}

let Tem1CV: Temas = Temas(nombre: "Tema1", subtemas: ["subtem1","subtem2","subtem3"])
let Tem2CV: Temas = Temas(nombre: "Tema2", subtemas: ["subtem1","subtem2","subtem6"])

let Tem1Termo: Temas = Temas(nombre: "Tema3", subtemas: ["subtem1","subtem2","subtem9"])
let Tem2Termo: Temas = Temas(nombre: "Tema4", subtemas: ["subtem1","subtem2","subtem12"])

let Tem1Meca: Temas = Temas(nombre: "Tema5", subtemas: ["subtem1","subtem2","subtem15"])
let Tem2Meca: Temas = Temas(nombre: "Tema6", subtemas: ["subtem1","subtem2","subtem18"])

// Arreglo de temas por materia
let TCV: [Temas] = [Tem1CV,Tem2CV]
let TTermo: [Temas] = [Tem1Termo,Tem2Termo]
let TMeca: [Temas] = [Tem1Meca,Tem2Meca]



