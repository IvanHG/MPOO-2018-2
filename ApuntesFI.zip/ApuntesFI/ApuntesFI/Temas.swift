//
//  Temas.swift
//  ApuntesFI
//
//  Created by macbook on 01/06/18.
//  Copyright © 2018 Macbook. All rights reserved.
//

import Foundation

struct Temas{
    let nombre: String
    let subtemas: [String]
}

let tema1CV: Temas = Temas(nombre: "Tema1", subtemas: ["subtem1","subtem2","subtem3"])
let tema2CV: Temas = Temas(nombre: "Tema2", subtemas: ["subtem1","subtem2","subtem3"])

let tema1Termo: Temas = Temas(nombre: "Tema1", subtemas: ["subtem1","subtem2","subtem3"])
let tema2Termo: Temas = Temas(nombre: "Tema2", subtemas: ["subtem1","subtem2","subtem3"])

let tema1Meca: Temas = Temas(nombre: "Tema1", subtemas: ["subtem1","subtem2","subtem3"])
let tema2Meca: Temas = Temas(nombre: "Tema2", subtemas: ["subtem1","subtem2","subtem3"])


