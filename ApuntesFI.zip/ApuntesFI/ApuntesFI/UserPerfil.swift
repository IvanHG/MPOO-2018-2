//
//  UserPerfil.swift
//  ApuntesFI
//
//  Created by macbook on 06/06/18.
//  Copyright © 2018 Macbook. All rights reserved.
//

import UIKit

class UserPerfil: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate {
    
    @IBOutlet weak var FPerfil: UIImageView!
    @IBOutlet weak var UName: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        FPerfil.layer.cornerRadius = FPerfil.bounds.width / 2.0
        FPerfil.layer.masksToBounds = true
        
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "celda_1", for: indexPath)
        cell.backgroundColor = UIColor.black
        
        
        return cell
    }
    


    
    



    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
