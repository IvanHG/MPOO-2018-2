//
//  UserPerfil.swift
//  ApuntesFI
//
//  Created by macbook on 06/06/18.
//  Copyright © 2018 Macbook. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase
import FirebaseAuth
import FirebaseStorage

class UserPerfil: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate {
    
    
    @IBOutlet weak var FPerfil: UIImageView!
    @IBOutlet weak var UName: UILabel!
    
    let ususario = Auth.auth().currentUser
    var refDatabase: DatabaseReference!
    var refStorage: StorageReference!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        refDatabase = Database.database().reference()
        
        

        
        FPerfil.layer.cornerRadius = FPerfil.bounds.width / 2.0
        FPerfil.layer.masksToBounds = true
        
        print ("Usuario actual: \(String(describing: ususario?.displayName!))")
        UName.text = ususario?.displayName!
        
        refDatabase.child("users").child((ususario?.uid)!).observe(.value) { (snapshot) in
            if let diccionario = snapshot.value as? [String: AnyObject] {
                self.UName.text = diccionario["nombre"] as? String
                self.FPerfil.image = diccionario["fotoPerfil"] as? UIImage
                
            }
        }
        
//        Databasee.database().reference().child("users").child(uid!).observereSingleEventOfType(.value, withBlock: {(sanapshot) in
//            if let dictionary = snapshot.value as? [String: AnyObjet]
//
//            //se asigna a variable el contenido de key en tipo String
//            variable = dictionary["key"] as? String
    
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "celda_1", for: indexPath)
        cell.backgroundColor = UIColor.black
        
        
        return cell
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
