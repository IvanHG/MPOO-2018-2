//
//  Inicio.swift
//  ApuntesFI
//
//  Created by macbook on 03/04/18.
//  Copyright © 2018 Macbook. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth

class Inicio: UIViewController{

    @IBOutlet weak var correoUsuario: UITextField!
    @IBOutlet weak var contraseñaUsuario: UITextField!
    
    @IBOutlet weak var alerta: UILabel!
    @IBOutlet weak var BSesion: UIButton!
    
    
    //autenticar usuario con fairebase
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        BSesion.isEnabled = false
//        SesionHabilitada(correoUsuario, contraseñaUsuario)
    }
    
//    func SesionHabilitada(_ usuario: UITextField, _ password: UITextField){
//        if (correoUsuario.text?.isEmpty)! || (contraseñaUsuario.text?.isEmpty)! {
//            BSesion.isEnabled = false
//        }else{
//            BSesion.isEnabled = true
//        }
//    }
    @IBAction func InicioSsion(_ sender: UIButton) {
        Auth.auth().createUser(withEmail: correoUsuario.text!, password: contraseñaUsuario.text!, completion: {(user, error) in
            
            if user != nil{
                print("todo bien")
            }else{
                print("hay errores")
            }
        })
    }
    

    

}
