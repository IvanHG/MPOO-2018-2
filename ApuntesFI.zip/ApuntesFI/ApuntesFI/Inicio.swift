//
//  Inicio.swift
//  ApuntesFI
//
//  Created by macbook on 03/04/18.
//  Copyright © 2018 Macbook. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth

class Inicio: UIViewController{

    @IBOutlet weak var correoUsuario: UITextField!
    @IBOutlet weak var contraseñaUsuario: UITextField!
    
    @IBOutlet weak var BSesion: UIButton!
    @IBOutlet weak var mensajeAlerta: UILabel!
    @IBOutlet weak var BCuenta: UIButton!
    
    
    //autenticar usuario con fairebase
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        BCuenta.layer.cornerRadius = 15
        BSesion.layer.cornerRadius = 15
        BSesion.isEnabled = false
    }
    
    @IBAction func InicioSsion(_ sender: UIButton) {
        
        Auth.auth().signIn(withEmail: correoUsuario.text!, password: contraseñaUsuario.text!, completion: {(user, error) in
            
            if user != nil{
                print("todo bien")
                print(user!.uid)
                userUID = user!.uid
                self.performSegue(withIdentifier:"Segue_Menu", sender:self)
                    
            }else{
                if let miError = error?.localizedDescription{
                    print(miError)
                    self.mostrarMensageAlerta("Hubo un error con tus datos")
                        
                }else{
                    print("ERROR FATAL")
                    self.mostrarMensageAlerta("Hubo un error con tus datos")
                }
            }
        })
    }
    
    @IBAction func userCaracteres(_ sender: Any) {
        
        if correoUsuario.text!.count != 0 &&  contraseñaUsuario.text!.count != 0 {
            BSesion.isEnabled = true
        }else{
            BSesion.isEnabled = false
        }
    }
    
    @IBAction func paswordCaracteres(_ sender: Any) {
        
        if correoUsuario.text!.count != 0 &&  contraseñaUsuario.text!.count != 0 {
            BSesion.isEnabled = true
        }
        else{
            BSesion.isEnabled = false
        }
    }
    
    func mostrarMensageAlerta(_ mensageUsuario:String){
                let alerta = UIAlertController(title:"Upss!!", message: mensageUsuario, preferredStyle: UIAlertControllerStyle.alert)
        
                let okAction = UIAlertAction(title:"OK", style: UIAlertActionStyle.default, handler: nil)
        
                alerta.addAction(okAction)
                present(alerta, animated:true, completion:nil)
            }
    
    
}
