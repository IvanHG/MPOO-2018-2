//
//  MenuPrincipal.swift
//  ApuntesFI
//
//  Created by macbook on 31/05/18.
//  Copyright © 2018 Macbook. All rights reserved.
//

import UIKit

class MenuPrincipal: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    
    @IBOutlet weak var MateriasCollectionView: UICollectionView!
    
    
    let materias = ["Calculo Vectorial", "Mecanica", "Termodinamica"]

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.MateriasCollectionView.delegate = self
        self.MateriasCollectionView.dataSource = self

    }

    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return materias.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "materia_cell", for: indexPath) as! MateriasCollectionViewCell
        
        cell.imgMateria.image = UIImage(named: materias[indexPath.row])
        cell.nomMateria.text = "Nombre Materia"
        
        return cell
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
