//
//  MenuPrincipal.swift
//  ApuntesFI
//
//  Created by macbook on 31/05/18.
//  Copyright © 2018 Macbook. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth

class MenuPrincipal: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    
    @IBOutlet weak var MateriasCollectionView: UICollectionView!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.MateriasCollectionView.delegate = self
        self.MateriasCollectionView.dataSource = self

    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return materias.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "materia_cell", for: indexPath) as! MateriasCollectionViewCell
        
        cell.imgMateria.image = UIImage(named: materias[indexPath.row].imagen)
        cell.nomMateria.text = materias[indexPath.row].nombre
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let tvt = storyboard?.instantiateViewController(withIdentifier: "MenuTemas") as? MenuTemas
        tvt?.indexP = indexPath.item
        self.navigationController?.pushViewController(tvt!, animated: true)
    }
    
    @IBAction func CerrarSesion(_ sender: UIBarButtonItem) {
        if Auth.auth().currentUser != nil{
            do{
                try? Auth.auth().signOut()
                print("sesion cerrada")
                
                if Auth.auth().currentUser == nil{
                    let IVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "Inicio") as! Inicio
                    self.present(IVC, animated: true, completion: nil)
                }
            }
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
