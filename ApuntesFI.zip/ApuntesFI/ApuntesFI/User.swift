//
//  User.swift
//  ApuntesFI
//
//  Created by macbook on 07/06/18.
//  Copyright © 2018 Macbook. All rights reserved.
//

import Foundation
import Firebase
import FirebaseAuth
import FirebaseStorage
import FirebaseDatabase

struct Usuario {
    
//    let ref: DatabaseReference
//    let data: StorageReference
//    let infoUser = [user: String ,correo: String, fotoPerfil: String(user.photoURL!)]
    let nombre: User!
}
