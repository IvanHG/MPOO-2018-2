//
//  Materias.swift
//  ApuntesFI
//
//  Created by macbook on 01/06/18.
//  Copyright © 2018 Macbook. All rights reserved.
//

import Foundation

struct Materias{
    
    let nombre: String
    let imagen: String
    let temas: [Temas]
    
}
var indexP: Int = 0

let CVectorial: Materias = Materias(nombre: "Cálculo Vctorial", imagen: "Calculo Vectorial", temas: [tema1CV,tema2CV] )

let Termodinamica: Materias = Materias(nombre: "Termodinámica", imagen: "Termodinamica", temas: [tema1Termo,tema2Termo])

let Mecanica: Materias = Materias(nombre: "Mecánica", imagen: "Mecanica", temas: [tema1Meca,tema2Meca])


let materias: [Materias] = [CVectorial, Termodinamica, Mecanica]
