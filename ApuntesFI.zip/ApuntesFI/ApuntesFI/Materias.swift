//
//  Materias.swift
//  ApuntesFI
//
//  Created by macbook on 01/06/18.
//  Copyright © 2018 Macbook. All rights reserved.
//

import Foundation

struct Materias{
    
    let nombre: String
    let imagen: String
    let temas: [Temas]
    
}


let CVectorial: Materias = Materias(nombre: "Cálculo Vctorial", imagen: "Calculo Vectorial", temas: TCV )

let Termodinamica: Materias = Materias(nombre: "Termodinámica", imagen: "Termodinamica", temas: TTermo)

let Mecanica: Materias = Materias(nombre: "Mecánica", imagen: "Mecanica", temas: TMeca)

//arrego de estructuras tipo Materias
let materias: [Materias] = [CVectorial, Termodinamica, Mecanica]

var userUID = ""
