//
//  CeldaTema.swift
//  ApuntesFI
//
//  Created by macbook on 01/06/18.
//  Copyright © 2018 Macbook. All rights reserved.
//

import UIKit

class CeldaTema: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
