//
//  ViewController.swift
//  Animacion_HI
//
//  Created by macbook on 24/04/18.
//

import UIKit

class ViewController: UIViewController {
    
    
    let tablero: UIView = {
        let vista = UIView()
        vista.backgroundColor = UIColor.brown
        vista.translatesAutoresizingMaskIntoConstraints = false
        
        return vista
    }()
    
    let imagen: UIImageView = {
        let im = UIImageView()
        im.image = UIImage(named: "cara")
        
        
        return im
    }()
    
    let controles: UIView = {
        let ct = UIView()
        ct.backgroundColor = UIColor.white
        ct.layer.cornerRadius = 15
        ct.translatesAutoresizingMaskIntoConstraints = false
        
        return ct
    }()
    
    let subir: UIButton = {
        let sb = UIButton(type: .system)
        sb.setImage(#imageLiteral(resourceName: "arriba"), for: .normal)
        sb.backgroundColor = UIColor.green
        sb.layer.cornerRadius = 5
        //sb.layer.masksToBounds = true
        sb.translatesAutoresizingMaskIntoConstraints = false
        sb.addTarget(self, action: #selector(AcSubir), for: .touchUpInside)
        
        
        return sb
    }()
    
    let bajar: UIButton = {
        let sb = UIButton(type: .system)
        sb.setImage(#imageLiteral(resourceName: "abajo"), for: .normal)
        sb.backgroundColor = UIColor.green
        sb.layer.cornerRadius = 5
        //sb.layer.masksToBounds = true
        sb.translatesAutoresizingMaskIntoConstraints = false
        sb.addTarget(self, action: #selector(AcBajar), for: .touchUpInside)
        
        
        return sb
    }()
    
    let derecha: UIButton = {
        let sb = UIButton(type: .system)
        sb.setImage(#imageLiteral(resourceName: "derecha"), for: .normal)
        sb.backgroundColor = UIColor.green
        sb.layer.cornerRadius = 5
        //sb.layer.masksToBounds = true
        sb.translatesAutoresizingMaskIntoConstraints = false
        sb.addTarget(self, action: #selector(AcDerecha), for: .touchUpInside)
        
        
        return sb
    }()
    
    let izquierda: UIButton = {
        let sb = UIButton(type: .system)
        sb.setImage(#imageLiteral(resourceName: "izquierda"), for: .normal)
        sb.backgroundColor = UIColor.green
        sb.layer.cornerRadius = 5
        //sb.layer.masksToBounds = true
        sb.translatesAutoresizingMaskIntoConstraints = false
        sb.addTarget(self, action: #selector(AcIzquierda), for: .touchUpInside)
        
        
        return sb
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.gray
        
        view.addSubview(tablero)
        view.addSubview(controles)
        
        tablero.addSubview(imagen)
        controles.addSubview(subir)
        controles.addSubview(bajar)
        controles.addSubview(derecha)
        controles.addSubview(izquierda)
        
        
    //Diseño de la vista en la que se desplazara la imagen y la que contine los botones de movimiento
        tablero.topAnchor.constraint(equalTo: view.topAnchor, constant: 40).isActive = true
        tablero.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
//        tablero.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
        tablero.widthAnchor.constraint(equalTo: view.widthAnchor, constant: -40).isActive = true
        tablero.heightAnchor.constraint(equalToConstant: 400).isActive = true
        
        controles.topAnchor.constraint(equalTo: tablero.bottomAnchor, constant: 60).isActive = true
        controles.centerXAnchor.constraint(equalTo: tablero.centerXAnchor).isActive = true
        controles.widthAnchor.constraint(equalTo: view.widthAnchor, constant: -280).isActive = true
        controles.heightAnchor.constraint(equalToConstant: 150).isActive = true
        
        
    // Ubicacion de los botones que controlan el movimiento
        subir.topAnchor.constraint(equalTo: controles.topAnchor, constant: 20).isActive = true
        subir.centerXAnchor.constraint(equalTo: controles.centerXAnchor).isActive = true
        
        bajar.bottomAnchor.constraint(equalTo: controles.bottomAnchor, constant: -20).isActive = true
        bajar.centerXAnchor.constraint(equalTo: controles.centerXAnchor).isActive = true
        
        derecha.rightAnchor.constraint(equalTo: controles.rightAnchor, constant: -20).isActive = true
        derecha.centerYAnchor.constraint(equalTo: controles.centerYAnchor).isActive = true
        
        izquierda.leftAnchor.constraint(equalTo: controles.leftAnchor, constant: 20).isActive = true
        izquierda.centerYAnchor.constraint(equalTo: controles.centerYAnchor).isActive = true
        
    //Ubicamos la imagen en el tablero
        imagen.frame = CGRect(x: 165.0, y: 180.0, width: 50.0, height: 50.0)
        
        
        
    }
    
    // funciones de los botones para mover la imagen en el tablero
    
    @objc func AcSubir(){
//        var centroY = imagen.center.y
//
//        if centroY != 25{
//            centroY += 5
//
//        }else{
//            print("limite inferior")
//        }
        
        imagen.center.y -= 5
    }

    @objc func AcBajar(){
//        var centroY = imagen.center.y
//
//        if centroY != 375{
//            centroY += 5
//
//        }else{
//            print("limite inferior")
//        }
        
        imagen.center.y += 5
    }
    
    @objc func AcDerecha(){
//        var centroX = imagen.center.x
//
//        if centroX == 350{
//            print("limite derecho")
//        }else{
//            centroX += 5
//        }
        
        imagen.center.x += 5
    }
    
    @objc func AcIzquierda(){
//        var centroX = imagen.center.x
//
//        if centroX == 25{
//            print("limite izquierdo")
//        }else{
//            centroX -= 5
//        }
        
        imagen.center.x -= 5
    }
}


