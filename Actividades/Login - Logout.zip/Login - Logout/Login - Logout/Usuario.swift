//
//  Usuario.swift
//  Login - Logout
//
//  Created by macbook on 19/04/18.
//  Copyright © 2018 MEEEE. All rights reserved.
//

import Foundation

struct User{
    var nombre: String
    var usuario: String
    var contraseña: String
}

var Usuarios: [User] = []
