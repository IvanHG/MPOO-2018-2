//
//  ViewController.swift
//  Actividad-2 (suma y resta)
//
//  Created by macbook on 06/03/18.
//  Copyright © 2018 Macbook. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var num1: UITextField!
    @IBOutlet weak var num2: UITextField!
    @IBOutlet weak var resultado: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    
    @IBAction func suma(_ sender: UIButton) {
        let a = Int(num1.text!)
        let b = Int(num2.text!)
        
        if num1.text == "" || num2.text == ""{
            mostrarMensageAlerta(mensageUsuario: "Introduce los dos numeros")
           
        }else{
            resultado.text = String(a! + b!)
        }
    }
    
    @IBAction func resta(_ sender: UIButton) {
        let a = Int(num1.text!)
        let b = Int(num2.text!)
        
        if num1.text == "" || num2.text == ""{
            mostrarMensageAlerta(mensageUsuario: "Introduce los dos numeros")
        }else{
            resultado.text = String(a! - b!)
        }
    }
    
    func mostrarMensageAlerta(mensageUsuario:String){
        let alerta = UIAlertController(title:"No lo haga compa!!", message:mensageUsuario, preferredStyle:UIAlertControllerStyle.alert)
        
        
        let okAction = UIAlertAction(title:"OK",style:UIAlertActionStyle.default, handler:nil)
        
        alerta.addAction(okAction)
        self.present(alerta, animated:true, completion:nil)
    }
}


