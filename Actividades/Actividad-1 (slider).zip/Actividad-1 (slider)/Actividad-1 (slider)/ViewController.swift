//
//  ViewController.swift
//  Actividad-1 (slider)
//
//  Created by macbook on 05/03/18.
//  Copyright © 2018 macbook. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var estaciones: UILabel!
    @IBOutlet weak var slider: UISlider!
    @IBOutlet weak var imgPrimavera: UIImageView!
    @IBOutlet weak var imgVerano: UIImageView!
    @IBOutlet weak var imgOtoño: UIImageView!
    @IBOutlet weak var imgInvierno: UIImageView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func valorSlider(_ sender: UISlider) {
        let valor = Int(slider.value * 100)
        
        imgVerano.alpha = 0
        imgInvierno.alpha = 0
        imgOtoño.alpha = 0
        imgPrimavera.alpha = 0
        
        switch valor {
        case 0...25:
            estaciones.text = "Invierno"
            imgInvierno.alpha = 1.0 - CGFloat(slider.value * 4)
            imgOtoño.alpha = CGFloat(slider.value * 4) - 0.0
            
        case 26...50:
            estaciones.text = "Otoño"
            imgOtoño.alpha = 2.0 - CGFloat(slider.value * 4)
            imgVerano.alpha = CGFloat(slider.value * 4) - 1.0
            
        case 51...75:
            estaciones.text = "Verano"
            imgVerano.alpha = 3.0 - CGFloat(slider.value * 4)
            imgPrimavera.alpha = CGFloat(slider.value * 4) - 2.0
            
        default:
            estaciones.text = "Primavera"
            imgPrimavera.alpha = 1
            
        }
        
        view.backgroundColor = UIColor(red: (CGFloat(slider.value)), green: (CGFloat(slider.value)), blue:/* (CGFloat(slider.value))*/ 0.5, alpha: 1)
        
    }

}

