//
//  ViewController.swift
//  Animate_HI
//
//  Created by macbook on 24/04/18.
//  Copyright © 2018 Jorge Adrian. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = UIColor.brown
        setupView()
        anima()
        
        }
    
    let imagen: UIImageView = {
        let iv = UIImageView()
        iv.image = UIImage(named: "avion")
        iv.contentMode = .scaleAspectFill
        iv.layer.cornerRadius = 50
        iv.layer.masksToBounds = true
    
        
        return iv
    }()
    
    func setupView(){
        view.addSubview(imagen)
        imagen.frame = CGRect(x: 0, y: 0, width: 200, height: 200)
        imagen.center.x -= view.bounds.width
        
    }
    
    func anima(){
        /*
        UIView.animate(withDuration: 1.0){
            self.imagen.center.x += self.view.bounds.width
            
        }
        */
        
//        UIView.animate(withDuration: 1.0, delay: 0.5, options: [.repeat, .autoreverse, .curveEaseIn], animations: {
//            self.imagen.center.x = self.view.bounds.width
//            self.imagen.frame.size.width += 200
//            self.imagen.frame.size.height += 200
//            self.imagen.alpha = 0.1
        
//        }, completion: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.imagen.center.y += 100
        self.imagen.alpha = 0.0
    }
    
    override func viewDidAppear(_ animated: Bool) {
        UIView.animate(withDuration: 1.0,
                       delay: 0.1,
                       usingSpringWithDamping: 0.5,
                       initialSpringVelocity: 0.0,
                       options: [],
                       animations: {
                        
                        self.imagen.center.y -=
                        
                       completion: <#T##((Bool) -> Void)?##((Bool) -> Void)?##(Bool) -> Void#>)
    }
        
    
        
        
    }


}

