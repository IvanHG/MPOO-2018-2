//
//  ViewController.swift
//  Animacion_HI
//
//  Created by macbook on 24/04/18.
//

import UIKit

class ViewController: UIViewController {
    
    
    let tablero: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.blue
        view.translatesAutoresizingMaskIntoConstraints = false
        view.layer.cornerRadius = 5
        view.layer.masksToBounds = true
        return view
    }()

    let ImNave: UIImageView = {
        let nav =  UIImageView()
        nav.image = UIImage(named: "cara")

        return nav
    }()
//
//    var actionUP: UIButton = {
//        var subir = UIButton(type: .system)
//        //subir.titleLabel?.font = UIFont.boldSystemFont(ofSize: 30)
//        subir.backgroundColor = UIColor.white
//        subir.layer.cornerRadius = 5
//        subir.setImage(#imageLiteral(resourceName: "arriba"), for: .normal)
//
//
//        subir.addTarget(self, action: #selector(subir1), for: .touchUpInside)
//
//        subir.translatesAutoresizingMaskIntoConstraints = false
//        return subir
//    }()
//
//    var actionDown: UIButton = {
//        var bajar = UIButton(type: .system)
//        bajar.setTitle("^", for: .normal)
//        bajar.titleLabel?.font = UIFont.boldSystemFont(ofSize: 30)
//        bajar.backgroundColor = UIColor.white
//        bajar.layer.cornerRadius = 5
//
//        bajar.addTarget(self, action: #selector(bajar1), for: .touchUpInside)
//
//        bajar.translatesAutoresizingMaskIntoConstraints = false
//        return bajar
//    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = UIColor.gray

////
       // vistaNave()
//        view.addSubview(actionUP)
        view.addSubview(tablero)
        
        //tablero.addSubview(ImNave)
        
        tablero.frame = CGRect(x: 0.0, y: 0.0, width: 100, height: 100)
        tablero.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        tablero.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
        
        
        
//        actionUP.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
//       // actionUP.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: 20).isActive = true
//
    }
//
//    func vistaNave(){
//        tablero.addSubview(ImNave)
//        ImNave.frame = CGRect(x: 0.0, y: 0.0, width: 50, height: 50)
//        ImNave.center.x = view.center.x
//        ImNave.center.y = view.center.y
//    }
//
//    @objc func subir1(){
//        UIView.animate(withDuration: 0.5, animations: {
//            self.ImNave.center.x += 10
//            })
//
//    }
//
//    @objc func bajar1(){
//        UIView.animate(withDuration: 0.5, animations: {
//            self.ImNave.center.x += 5
//        })
//
    


}

