//
//  ViewController.swift
//  Animacion_HI
//
//  Created by macbook on 24/04/18.
//

import UIKit

class ViewController: UIViewController {
    
    
    let tablero: UIView = {
        let vista = UIView()
        vista.backgroundColor = UIColor.brown
        vista.translatesAutoresizingMaskIntoConstraints = false
        
        return vista
    }()
    
    let imagen: UIImageView = {
        let im = UIImageView()
        im.image = UIImage(named: "cara")
        
        
        return im
    }()
    
    let controles: UIView = {
        let ct = UIView()
        ct.backgroundColor = UIColor.white
        ct.translatesAutoresizingMaskIntoConstraints = false
        
        return ct
    }()
    
    let subir: UIButton = {
        let sb = UIButton(type: .system)
        sb.setImage(#imageLiteral(resourceName: "arriba"), for: .normal)
        sb.backgroundColor = UIColor.green
        sb.layer.cornerRadius = 5
        sb.layer.masksToBounds = true
        sb.translatesAutoresizingMaskIntoConstraints = false
        sb.addTarget(self, action: #selector(AcSubir), for: .touchUpInside)
        
        
        return sb
    }()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.gray
        
        view.addSubview(tablero)
//      view.addSubview(controles)
        
        
        tablero.addSubview(imagen)
        controles.addSubview(subir)
        
//        tablero.frame = CGRect(x: 0.0, y: 0.0, width: 350.0, height: 400.0)
        
        

        tablero.topAnchor.constraint(equalTo: view.topAnchor, constant: 40).isActive = true
        tablero.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
//        tablero.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
        tablero.widthAnchor.constraint(equalTo: view.widthAnchor, constant: -40).isActive = true
        tablero.heightAnchor.constraint(equalToConstant: 400).isActive = true

        
        
        //subir.centerXAnchor.constraint(equalTo: controles.centerXAnchor).isActive = true
        
//        controles.frame = CGRect(x: 0.0, y: 0.0, width: 100.0, height: 100.0)
//        controles.center.x = view.center.x
        
        imagen.frame = CGRect(x: 0.0, y: 0.0, width: 50.0, height: 50.0)
        

//        subir.frame = CGRect(x: 0.0, y: 0.0, width: 50.0, height: 50.0)
//        subir.center.x = controles.center.x
        
    }
    
    @objc func AcSubir(){
        print("Hola")
        
    }

}

