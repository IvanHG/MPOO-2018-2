//
//  controles.swift
//  Animacion_HI
//
//  Created by macbook on 08/05/18.
//

import UIKit

class Controles: UIViewController, UIPageViewControllerDataSource, {
    
}

