//
//  ProductoCell.swift
//  Tabla2-gpo04
//
//  Created by iMac on 05/04/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit

class ProductoCell: UITableViewCell {

    

}
