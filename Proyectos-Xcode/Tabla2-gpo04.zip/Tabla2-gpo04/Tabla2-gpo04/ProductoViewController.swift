//
//  ProductoViewController.swift
//  Tabla2-gpo04
//
//  Created by Germán Santos Jaimes on 3/14/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit

class ProductoViewController: UIViewController {
    var nombre: String = ""
    
    @IBOutlet weak var imagen: UIImageView!
    @IBOutlet weak var etiqueta: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        etiqueta.text = nombre
        imagen.image = UIImage(named: nombre)
        print(nombre)
    }

    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
