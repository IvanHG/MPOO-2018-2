//
//  File.swift
//  collectionView
//
//  Created by macbook on 26/04/18.
//  Copyright © 2018 macbook. All rights reserved.
//

import UIKit

class CategoryViewCell : UICollectionViewCell, UICollectionViewDelegateFlowLayout, UICollectionViewDataSource, UICollectionViewDelegate{
    
    let identificador = "itemID"
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupLayaut()
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    let itemCategory: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        let cv = UICollectionView(frame: .zero, collectionViewLayout: layout)
        
        cv.translatesAutoresizingMaskIntoConstraints = false
        
        cv.backgroundColor = UIColor.red
        
        return cv
    }()
    
    func setupLayaut(){
        addSubview(itemCategory)
        
        itemCategory.dataSource = self
        itemCategory.delegate = self
        itemCategory.register(FotoCell.self, forCellWithReuseIdentifier: identificador)
        
        addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-14-[v0]-14-|", options: NSLayoutFormatOptions(), metrics: nil, views: ["v0": itemCategory]))
        
        addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-14-[v0]-14-|", options: NSLayoutFormatOptions(), metrics: nil, views: ["v0": itemCategory]))
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of items
        return 10
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: identificador, for: indexPath)
        
        // Configure the cell
        cell.backgroundColor = UIColor.black
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 100, height: 100)
    }
    
}
