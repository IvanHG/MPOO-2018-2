//
//  FotoCell.swift
//  collectionView
//
//  Created by macbook on 26/04/18.
//  Copyright © 2018 macbook. All rights reserved.
//

import UIKit

class FotoCell: UICollectionViewCell{
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupLayout()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    let imagenFoto: UIImageView = {
        let iv = UIImageView()
        iv.image = UIImage(named: "Jigglypuff")
        
        return iv
    }()
    
    func setupLayout(){
        addSubview(imagenFoto)
        
        imagenFoto.frame = CGRect(x: 0, y: 0, width: frame.width, height: frame.width)
    }
    
}
