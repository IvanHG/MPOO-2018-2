//
//  DetailViewController.swift
//  Table02-gpo05
//
//  Created by Germán Santos Jaimes on 3/15/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {

    @IBOutlet weak var imagenDetail: UIImageView!
    @IBOutlet weak var etiqueta: UILabel!
   // var productos: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        etiqueta.text = panes[IndexP].nombre
        imagenDetail.image = UIImage(named: panes[IndexP].imagen )
        
    }

    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
