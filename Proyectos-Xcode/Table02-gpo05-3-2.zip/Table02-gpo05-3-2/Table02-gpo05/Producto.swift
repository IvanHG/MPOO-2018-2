//
//  Producto.swift
//  Table02-gpo05
//
//  Created by Germán Santos Jaimes on 3/15/18.
//  Copyright © 2018 iosLab. All rights reserved.
//

import Foundation

struct Producto{
    var nombre: String
    var desc: String
    var precio: Double
    var imagen: String
}
var IndexP = 0  //variable para acceder a las propiedades de cualquier elemento
                //del arreglo panes en cuanquier controlador

let brownies = Producto(nombre: "Brownies",
                        desc: "Delicioso pan de chocolate",
                        precio: 2.50,
                        imagen: "brownies")
let bagels = Producto(nombre: "Bagels",
                      desc: "Producto muy parecido a las donas",
                      precio: 4.50,
                      imagen: "bagels")
let butter = Producto(nombre: "Mantequilla",
                      desc: "Producto elaborado de grasa vegetal",
                      precio: 12.00,
                      imagen: "butter")
let cheese = Producto(nombre: "Queso",
                      desc: "Producto derivado de la leche",
                      precio: 11.00,
                      imagen: "cheese")
let coffee = Producto(nombre: "Café",
                      desc: "Especialmente diseñado para aquellos universitarios que optan por desvelarse viendo Netflix",
                      precio: 10.50,
                      imagen: "coffee")
let cookies = Producto(nombre: "Galletitas",
                       desc: "Elaboradas artesanalmente por manos mexicanas",
                       precio: 7.00,
                       imagen: "cookies")
let donuts = Producto(nombre: "Donas",
                      desc: "Pan hecho a absase de arina cubierta de azucar y con un hueco en el centro",
                      precio: 4.50,
                      imagen: "donuts")
let granola = Producto(nombre: "Ganola",
                       desc: "semillas nutritivas para quitar el habre y estar sano",
                       precio: 20.00,
                       imagen: "granola")
let juice = Producto(nombre: "Jugo",
                     desc: "Poducto hechoi a base de naranja con un toque de miel",
                     precio: 15.00,
                     imagen: "juice")
let lemonade = Producto(nombre: "Limonada",
                        desc: "Como su nombre lo dice es aguga con limon y azucar",
                        precio: 10.00,
                        imagen: "lemonade")
let lettuce = Producto(nombre: "Lechuga",
                       desc: "Verdura verde, muy buena para la salud y las dietas",
                       precio: 9.50,
                       imagen: "lettuce")
let milk = Producto(nombre: "Leche de vaca",
                    desc: "Presentacionde 1 lt para crecer fuerte y sano",
                    precio: 12.50,
                    imagen: "milk")
let oatmeal = Producto(nombre: "Avena",
                       desc: "Es rica en proteínas de alto valor biológico, grasas y un gran número de vitaminas y minerales",
                       precio: 16.50,
                       imagen: "oatmeal")
let onions = Producto(nombre: "Cebollas",
                      desc: "Los frutos de la cebolla son diminutas cápsulas llenas de semillas finas y negras.",
                      precio: 1.00,
                      imagen: "onions")
let potato = Producto(nombre: "Platanos",
                      desc: "Rico en fibra, potasio y algunas vitaminas beneficiosas para la salud",
                      precio: 12.50,
                      imagen: "potato")
let tea = Producto(nombre: "Te",
                   desc: "Producto idoneo para cunado se esta enfermo de gripa",
                   precio: 8.00,
                   imagen: "tea")
let tomato = Producto(nombre: "Jitomate",
                      desc: "Son bayas de color rojizo que se caracterizan por su pulpa con múltiples semillas y por su jugo.",
                      precio: 22.00,
                      imagen: "tomato")
let yogurt = Producto(nombre: "Yogurt",
                      desc: "Producto lácteo de consistencia generalmente cremosa que se obtiene a partir de la fermentación de la leche",
                      precio: 11.50,
                      imagen: "yogurt")

var panes = [brownies,bagels,butter,cheese,coffee,cookies,donuts,granola,juice,lemonade,lettuce,milk,oatmeal,onions,potato,tea,tomato,yogurt]


