//
//  ViewController.swift
//  Test
//
//  Created by macbook on 08/03/18.
//  Copyright © 2018 Macbook. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    var nombres = ["Pedro", "Luis", "Daniel", "Ivan","Pedro", "Luis", "Daniel", "Ivan","Pedro", "Luis", "Daniel", "Ivan"]
    
    
    
    //motodios que el protyocolo utiliza
    
    //para determinar las secciones o numero de renglones que tendra la seccion del table view
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return nombres.count
    }
    
    
    //por cada renglon existe un indexpath, da el numero de renglon que se selecciono, (pintar las celdas)
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let cellIdentifier = "Cell"
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath)
        
        cell.textLabel?.text = nombres[indexPath.row]
        return cell
        
    }

    //nos dice la celda que fue presionada
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let optionMenu = UIAlertController(title: "Compa", message: "Que tranza!!!", preferredStyle: .alert /*.alert*/)
        
        let cancelOption = UIAlertAction(title: "Palomita", style: .cancel , handler: /*clousure*/ {(action: UIAlertAction!) -> Void in
        
        let cell = tableView.cellForRow(at: indexPath)
        cell?.accessoryType = .checkmark
        }
        )
        
        let okOption = UIAlertAction(title: "Cancelar", style: .default, handler: {(action: UIAlertAction!) -> Void in
            
            let cell = tableView.cellForRow(at: indexPath)
            cell?.accessoryType = .detailButton
        }
        )
    
        optionMenu.addAction(cancelOption)
        optionMenu.addAction(okOption)
        present(optionMenu,animated: true, completion: nil)
        
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }


}

