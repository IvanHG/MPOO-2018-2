import UIKit

class AnimOptionsViewController: UIViewController {

    var originX: CGFloat = 0
    @IBOutlet var views: [UIView]!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        originX = views[0].center.x
    }

    
    @IBAction func startPressed(_ sender: UIButton) {
        
    }
    
    @IBAction func stopPressed(_ sender: UIButton) {
        
        for view in views {
            
            view.transform = .identity
            view.center.x = originX
            view.layer.removeAllAnimations()
            
        }
        
    }
    
    
}
