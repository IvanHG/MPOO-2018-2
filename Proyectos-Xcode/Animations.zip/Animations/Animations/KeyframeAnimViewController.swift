import UIKit

class KeyframeAnimViewController: UIViewController {

    
    @IBOutlet weak var planeImage: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func viewDidAppear(_ animated: Bool) {
        
    }
    
}
