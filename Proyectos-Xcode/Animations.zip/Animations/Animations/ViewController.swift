import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var squareView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
 
    @IBAction func customButtonPressed(_ sender: UIButton) {
        
        UIView.animate(withDuration: 3) {
            self.squareView.center = self.view.center
        }
        
    }
    
    

}

