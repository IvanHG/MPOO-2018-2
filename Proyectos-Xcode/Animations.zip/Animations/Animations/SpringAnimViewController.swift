import UIKit

class SpringAnimViewController: UIViewController {

    
    @IBOutlet weak var heartImage: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func logInButtonPressed(_ sender: UIButton) {
        
        
        
    }
}
