import UIKit

class MoreControlViewController: UIViewController {

    @IBOutlet weak var squareView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    @IBAction func centerButtonPressed(_ sender: UIButton) {
        
        
        
    }
    
    @IBAction func frameButtonPressed(_ sender: UIButton) {
        
        
        
    }
    
    @IBAction func boundsButtonPressed(_ sender: UIButton) {
        
        
        
    }
    
    @IBAction func alphaButtonPressed(_ sender: UIButton) {
        
        
        
    }
    
    @IBAction func transformButtonPressed(_ sender: UIButton) {
        
        
        
    }
    
    @IBAction func colorButtonPressed(_ sender: UIButton) {
        
        
        
    }
    
    @IBAction func customButtonPressed(_ sender: UIButton) {
        // Use Completion block
        
        
    }
    
}
