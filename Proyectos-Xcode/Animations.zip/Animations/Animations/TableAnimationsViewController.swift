import UIKit

class TableAnimationsViewController: UITableViewController {

    @IBOutlet weak var square1: UIView!
    
    @IBOutlet weak var square2: UIView!
    
    @IBOutlet weak var square3: UIView!
    
    @IBOutlet weak var square4: UIView!
    
    @IBOutlet weak var square5: UIView!
    
        
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
    }

    
    override func viewDidAppear(_ animated: Bool) {
        
        UIView.animate(withDuration: 2, delay: 0, options: [.repeat], animations: {
            
            self.square1.center.x += 250
            
        }, completion: nil)
        
        UIView.animate(withDuration: 2, delay: 0, options: [.repeat, .autoreverse], animations: {
            
            self.square2.center.x += 200
            self.square2.transform = CGAffineTransform(rotationAngle: CGFloat.pi)
            
        }, completion: nil)
        
        
        UIView.animate(withDuration: 2, delay: 0, options: [.repeat, .autoreverse, .curveEaseIn], animations: {
            
            self.square3.center.x += 160
            
        }, completion: nil)
        
        
        
        UIView.animate(withDuration: 2, delay: 1, usingSpringWithDamping: 0.1, initialSpringVelocity: 0, options: [.repeat], animations: {
            
            self.square4.bounds = CGRect(x: 0, y: 0, width: 150, height: 30)
            
        }, completion: nil)
        
        
        UIView.animate(withDuration: 2, delay: 0, options: [.repeat, .autoreverse, .curveEaseInOut], animations: {
            
            self.square5.center.x += 200
            self.square5.transform = CGAffineTransform(rotationAngle: 4.5204)
            self.square5.backgroundColor = UIColor.blue
            
        }, completion: nil)
        
        
        
    }


}
