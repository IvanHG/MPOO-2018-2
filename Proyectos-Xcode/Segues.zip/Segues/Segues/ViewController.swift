//
//  ViewController.swift
//  Segues
//
//  Created by macbook on 05/04/18.
//  Copyright © 2018 Macbook. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var texto: UITextField!
   var valores = UserDefaults.standard
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let valorCaja = valores.object(forKey: "caja"){
            print("Hay valor")
            texto.text = valorCaja as! String
        }else{
            print("no hay valor")
        }
        
    }

    
    @IBAction func nextView(_ sender: Any) {
        let contenido = texto.text
        if contenido != "" {
            print("Hay texto")
            valores.setValue(texto.text, forKey: "caja")
            
            
        }else{
            
            showError()
            self.navigationController?.pushViewController(SecondViewController(), animated: true)
        }
    }
    
    func showError(){
        let ventanaError = UIAlertController(title: "Error", message: "No existen datos en la caja", preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
        
        ventanaError.addAction(okAction)
        present(ventanaError, animated: true, completion: nil)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        print("ejecutando el segue")
    }
    
    override func performSegue(withIdentifier identifier: String, sender: Any?) {
        print("moviendome a la segunda vista")
    }
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        return true
    }
}

